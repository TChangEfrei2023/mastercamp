--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE elevalert_db;
--
-- Name: elevalert_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE elevalert_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'French_France.1252';


ALTER DATABASE elevalert_db OWNER TO postgres;

\connect elevalert_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Adresse; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Adresse" (
    "idAdresse" integer NOT NULL,
    rue text,
    "codePostal" text,
    ville text
);


ALTER TABLE public."Adresse" OWNER TO postgres;

--
-- Name: Adresse_idAdresse_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Adresse_idAdresse_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Adresse_idAdresse_seq" OWNER TO postgres;

--
-- Name: Adresse_idAdresse_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Adresse_idAdresse_seq" OWNED BY public."Adresse"."idAdresse";


--
-- Name: Breakdown_idBreakdown_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Breakdown_idBreakdown_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public."Breakdown_idBreakdown_seq" OWNER TO postgres;

--
-- Name: Breakdown; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Breakdown" (
    "idBreakdown" integer DEFAULT nextval('public."Breakdown_idBreakdown_seq"'::regclass) NOT NULL,
    "idComponent" integer NOT NULL,
    "dateDebut" date NOT NULL,
    "dateFin" date,
    reception boolean NOT NULL
);


ALTER TABLE public."Breakdown" OWNER TO postgres;

--
-- Name: Breakdown_idError_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Breakdown_idError_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Breakdown_idError_seq" OWNER TO postgres;

--
-- Name: Breakdown_idError_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Breakdown_idError_seq" OWNED BY public."Breakdown"."idComponent";


--
-- Name: Client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Client" (
    "idClient" integer NOT NULL,
    mdp text NOT NULL,
    nom text NOT NULL,
    email text NOT NULL,
    tel text NOT NULL,
    "idAdresse" integer NOT NULL
);


ALTER TABLE public."Client" OWNER TO postgres;

--
-- Name: Client_idAdresse_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Client_idAdresse_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Client_idAdresse_seq" OWNER TO postgres;

--
-- Name: Client_idAdresse_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Client_idAdresse_seq" OWNED BY public."Client"."idAdresse";


--
-- Name: Client_idClient_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Client_idClient_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Client_idClient_seq" OWNER TO postgres;

--
-- Name: Client_idClient_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Client_idClient_seq" OWNED BY public."Client"."idClient";


--
-- Name: Component; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Component" (
    "idComponent" integer NOT NULL,
    "idElevator" integer NOT NULL,
    "idError" integer NOT NULL,
    nom text NOT NULL,
    status boolean NOT NULL
);


ALTER TABLE public."Component" OWNER TO postgres;

--
-- Name: Component_idComponent_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Component_idComponent_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Component_idComponent_seq" OWNER TO postgres;

--
-- Name: Component_idComponent_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Component_idComponent_seq" OWNED BY public."Component"."idComponent";


--
-- Name: Elevator; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Elevator" (
    "idElevator" integer NOT NULL,
    "idClient" integer NOT NULL,
    "idAdresse" integer NOT NULL
);


ALTER TABLE public."Elevator" OWNER TO postgres;

--
-- Name: Elevator_idAdresse_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Elevator_idAdresse_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Elevator_idAdresse_seq" OWNER TO postgres;

--
-- Name: Elevator_idAdresse_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Elevator_idAdresse_seq" OWNED BY public."Elevator"."idAdresse";


--
-- Name: Elevator_idClient_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Elevator_idClient_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Elevator_idClient_seq" OWNER TO postgres;

--
-- Name: Elevator_idClient_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Elevator_idClient_seq" OWNED BY public."Elevator"."idClient";


--
-- Name: Elevator_idElevator_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Elevator_idElevator_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Elevator_idElevator_seq" OWNER TO postgres;

--
-- Name: Elevator_idElevator_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Elevator_idElevator_seq" OWNED BY public."Elevator"."idElevator";


--
-- Name: Employe; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Employe" (
    "idEmploye" integer NOT NULL,
    mdp text NOT NULL,
    nom text NOT NULL,
    prenom text NOT NULL
);


ALTER TABLE public."Employe" OWNER TO postgres;

--
-- Name: Employe_idEmploye_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Employe_idEmploye_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Employe_idEmploye_seq" OWNER TO postgres;

--
-- Name: Employe_idEmploye_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Employe_idEmploye_seq" OWNED BY public."Employe"."idEmploye";


--
-- Name: Error; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Error" (
    "idError" integer NOT NULL,
    description text NOT NULL
);


ALTER TABLE public."Error" OWNER TO postgres;

--
-- Name: Error_idError_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Error_idError_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Error_idError_seq" OWNER TO postgres;

--
-- Name: Error_idError_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Error_idError_seq" OWNED BY public."Error"."idError";


--
-- Name: Adresse idAdresse; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Adresse" ALTER COLUMN "idAdresse" SET DEFAULT nextval('public."Adresse_idAdresse_seq"'::regclass);


--
-- Name: Breakdown idComponent; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Breakdown" ALTER COLUMN "idComponent" SET DEFAULT nextval('public."Breakdown_idError_seq"'::regclass);


--
-- Name: Client idClient; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Client" ALTER COLUMN "idClient" SET DEFAULT nextval('public."Client_idClient_seq"'::regclass);


--
-- Name: Client idAdresse; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Client" ALTER COLUMN "idAdresse" SET DEFAULT nextval('public."Client_idAdresse_seq"'::regclass);


--
-- Name: Component idComponent; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Component" ALTER COLUMN "idComponent" SET DEFAULT nextval('public."Component_idComponent_seq"'::regclass);


--
-- Name: Elevator idElevator; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Elevator" ALTER COLUMN "idElevator" SET DEFAULT nextval('public."Elevator_idElevator_seq"'::regclass);


--
-- Name: Elevator idClient; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Elevator" ALTER COLUMN "idClient" SET DEFAULT nextval('public."Elevator_idClient_seq"'::regclass);


--
-- Name: Elevator idAdresse; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Elevator" ALTER COLUMN "idAdresse" SET DEFAULT nextval('public."Elevator_idAdresse_seq"'::regclass);


--
-- Name: Employe idEmploye; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employe" ALTER COLUMN "idEmploye" SET DEFAULT nextval('public."Employe_idEmploye_seq"'::regclass);


--
-- Name: Error idError; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Error" ALTER COLUMN "idError" SET DEFAULT nextval('public."Error_idError_seq"'::regclass);


--
-- Data for Name: Adresse; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Adresse" ("idAdresse", rue, "codePostal", ville) FROM stdin;
\.
COPY public."Adresse" ("idAdresse", rue, "codePostal", ville) FROM '$$PATH$$/3065.dat';

--
-- Data for Name: Breakdown; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Breakdown" ("idBreakdown", "idComponent", "dateDebut", "dateFin", reception) FROM stdin;
\.
COPY public."Breakdown" ("idBreakdown", "idComponent", "dateDebut", "dateFin", reception) FROM '$$PATH$$/3075.dat';

--
-- Data for Name: Client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Client" ("idClient", mdp, nom, email, tel, "idAdresse") FROM stdin;
\.
COPY public."Client" ("idClient", mdp, nom, email, tel, "idAdresse") FROM '$$PATH$$/3068.dat';

--
-- Data for Name: Component; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Component" ("idComponent", "idElevator", "idError", nom, status) FROM stdin;
\.
COPY public."Component" ("idComponent", "idElevator", "idError", nom, status) FROM '$$PATH$$/3077.dat';

--
-- Data for Name: Elevator; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Elevator" ("idElevator", "idClient", "idAdresse") FROM stdin;
\.
COPY public."Elevator" ("idElevator", "idClient", "idAdresse") FROM '$$PATH$$/3072.dat';

--
-- Data for Name: Employe; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Employe" ("idEmploye", mdp, nom, prenom) FROM stdin;
\.
COPY public."Employe" ("idEmploye", mdp, nom, prenom) FROM '$$PATH$$/3061.dat';

--
-- Data for Name: Error; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Error" ("idError", description) FROM stdin;
\.
COPY public."Error" ("idError", description) FROM '$$PATH$$/3063.dat';

--
-- Name: Adresse_idAdresse_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Adresse_idAdresse_seq"', 1, true);


--
-- Name: Breakdown_idBreakdown_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Breakdown_idBreakdown_seq"', 1, true);


--
-- Name: Breakdown_idError_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Breakdown_idError_seq"', 1, false);


--
-- Name: Client_idAdresse_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Client_idAdresse_seq"', 1, false);


--
-- Name: Client_idClient_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Client_idClient_seq"', 1, true);


--
-- Name: Component_idComponent_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Component_idComponent_seq"', 1, true);


--
-- Name: Elevator_idAdresse_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Elevator_idAdresse_seq"', 1, false);


--
-- Name: Elevator_idClient_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Elevator_idClient_seq"', 1, true);


--
-- Name: Elevator_idElevator_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Elevator_idElevator_seq"', 1, true);


--
-- Name: Employe_idEmploye_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Employe_idEmploye_seq"', 1, true);


--
-- Name: Error_idError_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Error_idError_seq"', 1, false);


--
-- Name: Adresse Adresse_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Adresse"
    ADD CONSTRAINT "Adresse_pkey" PRIMARY KEY ("idAdresse");


--
-- Name: Breakdown Breakdown_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Breakdown"
    ADD CONSTRAINT "Breakdown_pkey" PRIMARY KEY ("idBreakdown");


--
-- Name: Client Client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Client"
    ADD CONSTRAINT "Client_pkey" PRIMARY KEY ("idClient");


--
-- Name: Component Component_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Component"
    ADD CONSTRAINT "Component_pkey" PRIMARY KEY ("idComponent");


--
-- Name: Elevator Elevator_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Elevator"
    ADD CONSTRAINT "Elevator_pkey" PRIMARY KEY ("idElevator");


--
-- Name: Employe Employe_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employe"
    ADD CONSTRAINT "Employe_pkey" PRIMARY KEY ("idEmploye");


--
-- Name: Error Error_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Error"
    ADD CONSTRAINT "Error_pkey" PRIMARY KEY ("idError");


--
-- Name: Client Adresse_idAdresse_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Client"
    ADD CONSTRAINT "Adresse_idAdresse_fkey" FOREIGN KEY ("idAdresse") REFERENCES public."Adresse"("idAdresse") MATCH FULL ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: Elevator Adresse_idAdresse_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Elevator"
    ADD CONSTRAINT "Adresse_idAdresse_fkey" FOREIGN KEY ("idAdresse") REFERENCES public."Adresse"("idAdresse");


--
-- Name: Breakdown Breakdown_idComponent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Breakdown"
    ADD CONSTRAINT "Breakdown_idComponent_fkey" FOREIGN KEY ("idComponent") REFERENCES public."Component"("idComponent") MATCH FULL;


--
-- Name: Elevator Client_idClient_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Elevator"
    ADD CONSTRAINT "Client_idClient_fkey" FOREIGN KEY ("idClient") REFERENCES public."Client"("idClient") MATCH FULL ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: Component Component_idElevatore_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Component"
    ADD CONSTRAINT "Component_idElevatore_fkey" FOREIGN KEY ("idElevator") REFERENCES public."Elevator"("idElevator") MATCH FULL;


--
-- Name: Component Component_idError_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Component"
    ADD CONSTRAINT "Component_idError_fkey" FOREIGN KEY ("idError") REFERENCES public."Error"("idError") MATCH FULL;


--
-- PostgreSQL database dump complete
--

